# Create vpc network
gcloud compute networks create lab-vpc --subnet-mode=custom;

# Create subnet in vpc network
gcloud compute networks subnets create subnet-01 --network=lab-vpc --range=192.168.0.0/24 --region=us-central1;

# Create firewall rules in vpc network
gcloud compute firewall-rules create lab-vpc-ports --network lab-vpc --allow tcp:3389,tcp:22,tcp:80;

# Create service account
echo $DEVSHELL_PROJECT_ID;
gcloud iam service-accounts create ingest-logs --display-name="service-account-ingest-logs";
gcloud projects add-iam-policy-binding $DEVSHELL_PROJECT_ID --member serviceAccount:ingest-logs@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --role roles/editor;

# Create windows virtual machine
gcloud compute instances create win-websrv --image-family=windows-2022 --image-project=windows-cloud  --machine-type=e2-medium --zone=us-central1-a --network=lab-vpc --subnet=subnet-01 --service-account=ingest-logs@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --metadata=windows-startup-script-url=https://github.com/ahmadzahoory/gcpcev2/raw/main/web-script-13-01.ps1;


# Create ubuntu virtual machine
gcloud compute instances create lin-websrv --image-family=ubuntu-2204-lts  --image-project=ubuntu-os-cloud --machine-type=e2-medium --zone=us-central1-a --network=lab-vpc --subnet=subnet-01 --service-account=ingest-logs@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --metadata=startup-script-url=https://github.com/ahmadzahoory/gcpcev2/raw/main/web-script-13-01.sh


