import functions_framework
import google.auth
from google.cloud import storage
from google.cloud import compute_v1
import json

@functions_framework.http
def process(request):
    project_id = "PROJECT-ID"  # your-project-id

    # Set the name of the GCS bucket and JSON file
    bucket_name = "BUCKET-NAME"
    json_file = "start.json"

    # Authenticate with GCP
    #credentials, _ = google.auth.default()
    storage_client = storage.Client()
    instance_client = compute_v1.InstancesClient()

    request = {
        "project": project_id,
    }

    agg_list = instance_client.aggregated_list(request=request)

    # Load the JSON file from GCS
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.blob(json_file)
    json_data = blob.download_as_string()
    print(f"loaded labels is {json_data}")
    json_data = json.loads(json_data)
    def check_label(instance, json_data):
        labels = instance.labels
        for k,v in json_data.items():
            if k in labels:
                if v == labels[k]:
                    return True
        return False
    for zone, response in agg_list:
        if response.instances:
            for instance in response.instances:
                print(f" - {instance.name} ({instance.machine_type})")
                res = check_label(instance, json_data)
                if res:
                    print(type(instance.status))
                    if instance.status == "RUNNING":
                        print(f"Instance {instance.name} with labels is already in running state")
                    else:
                        zone_id = zone.split("/")[1].strip()
                        instance_client.start(project=project_id, zone=zone_id, instance=str(instance.name))
                        print(f"Instance {instance.name} with labels is termianted state and its started") 
    return "process"
