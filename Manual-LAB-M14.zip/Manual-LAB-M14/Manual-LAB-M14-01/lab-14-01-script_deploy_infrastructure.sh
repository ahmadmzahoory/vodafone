# Create vpc network
gcloud compute networks create lab-vpc --subnet-mode=custom;

# Create subnet in vpc network subnet in region-1
gcloud compute networks subnets create subnet-01 --network=lab-vpc --range=172.16.0.0/24 --region=us-central1;
# Create subnet in vpc network subnet in region-2
gcloud compute networks subnets create subnet-02 --network=lab-vpc --range=172.18.0.0/24 --region=us-west1;
# Create firewall rules in vpc network
gcloud compute firewall-rules create lab-vpc-ports --network lab-vpc --allow tcp:22;

# Create service account
echo $DEVSHELL_PROJECT_ID;
gcloud iam service-accounts create function-compute --display-name="service-account-function-compute";
gcloud projects add-iam-policy-binding $DEVSHELL_PROJECT_ID --member serviceAccount:function-compute@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --role roles/compute.admin;
gcloud projects add-iam-policy-binding $DEVSHELL_PROJECT_ID --member serviceAccount:function-compute@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --role roles/compute.instanceAdmin;
gcloud projects add-iam-policy-binding $DEVSHELL_PROJECT_ID --member serviceAccount:function-compute@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --role roles/compute.instanceAdmin.v1;
gcloud projects add-iam-policy-binding $DEVSHELL_PROJECT_ID --member serviceAccount:function-compute@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --role roles/storage.admin;
gcloud projects add-iam-policy-binding $DEVSHELL_PROJECT_ID --member serviceAccount:function-compute@$DEVSHELL_PROJECT_ID.iam.gserviceaccount.com --role roles/storage.objectAdmin;

# Create windows virtual machine in region-1
gcloud compute instances create vm-01 --image-family=ubuntu-2204-lts --image-project=ubuntu-os-cloud --machine-type=n1-standard-1 --zone=us-central1-a --network=lab-vpc --subnet=subnet-01;
gcloud compute instances add-labels vm-01 --zone=us-central1-a --labels=project=hrms,type=prod,costcenter=cc554;
gcloud compute instances create vm-02 --image-family=ubuntu-2204-lts --image-project=ubuntu-os-cloud --machine-type=n1-standard-1 --zone=us-central1-a --network=lab-vpc --subnet=subnet-01;
gcloud compute instances add-labels vm-02 --zone=us-central1-a --labels=project=erp,type=prod;
# Create windows virtual machine in region-2
gcloud compute instances create vm-03 --image-family=ubuntu-2204-lts --image-project=ubuntu-os-cloud --machine-type=n1-standard-1 --zone=us-west1-a --network=lab-vpc --subnet=subnet-02;
gcloud compute instances add-labels vm-03 --zone=us-west1-a --labels=project=hrms,type=prod;
gcloud compute instances create vm-04 --image-family=ubuntu-2204-lts --image-project=ubuntu-os-cloud --machine-type=n1-standard-1 --zone=us-west1-a --network=lab-vpc --subnet=subnet-02;
gcloud compute instances add-labels vm-04 --zone=us-west1-a --labels=project=crm,type=uat
